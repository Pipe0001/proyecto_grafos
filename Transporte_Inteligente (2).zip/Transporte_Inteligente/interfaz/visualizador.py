import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import networkx as nx
import matplotlib.pyplot as plt
from src.utils import cargar_red_desde_json

# Colores por tipo de estación
COLOR_TIPOS = {
    "metro": "skyblue",
    "bus": "lightgreen",
    "intermodal": "salmon",
    "desconocido": "lightgray"
}

def visualizar_red(ruta_json: str):
    grafo = cargar_red_desde_json(ruta_json)
    G = nx.DiGraph()

    colores_nodos = {}
    for nombre, vertex in grafo.vertices.items():
        G.add_node(nombre)
        tipo = getattr(vertex, 'tipo', 'desconocido')
        colores_nodos[nombre] = COLOR_TIPOS.get(tipo, "lightgray")

    for origen, edges in grafo.adjacency.items():
        for edge in edges:
            G.add_edge(origen, edge.destination.name, weight=edge.weight)

    pos = nx.spring_layout(G, seed=42)
    plt.figure(figsize=(10, 6))

    # Dibujar nodos con colores por tipo
    nx.draw_networkx_nodes(
        G, pos, 
        node_color=[colores_nodos[n] for n in G.nodes()],
        node_size=2000, edgecolors='black'
    )
    
    nx.draw_networkx_labels(G, pos, font_size=12, font_weight='bold')
    nx.draw_networkx_edges(G, pos, arrowstyle='-|>', arrowsize=25, edge_color='gray', width=2)
    labels = nx.get_edge_attributes(G, 'weight')
    nx.draw_networkx_edge_labels(G, pos, edge_labels=labels, font_color='red', font_size=10)

    plt.title("🗺️ Red de Transporte Urbano Inteligente", fontsize=14)
    plt.axis('off')
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    visualizar_red('data/red_ejemplo.json')
