import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import networkx as nx
import plotly.graph_objects as go
from src.utils import cargar_red_desde_json

# Cargar grafo
grafo = cargar_red_desde_json('data/red_ejemplo.json')
G = nx.DiGraph()

colores = {
    "metro": "skyblue",
    "bus": "lightgreen",
    "intermodal": "salmon",
    "desconocido": "gray"
}

tipos = {}
for nombre, vertex in grafo.vertices.items():
    G.add_node(nombre)
    tipos[nombre] = getattr(vertex, 'tipo', 'desconocido')

for origen, edges in grafo.adjacency.items():
    for edge in edges:
        G.add_edge(origen, edge.destination.name, weight=edge.weight)

# Posiciones fijas
pos = nx.spring_layout(G, seed=42)

# Función para construir la figura del grafo
def construir_figura_grafo(camino_resaltado=None):
    fig = go.Figure()

    # Aristas normales
    for u, v, d in G.edges(data=True):
        fig.add_trace(go.Scatter(
            x=[pos[u][0], pos[v][0]],
            y=[pos[u][1], pos[v][1]],
            line=dict(width=2, color='gray'),
            mode='lines',
            hoverinfo='none',
            showlegend=False
        ))

    # Aristas resaltadas (camino)
    if camino_resaltado and len(camino_resaltado) > 1:
        for i in range(len(camino_resaltado) - 1):
            u = camino_resaltado[i]
            v = camino_resaltado[i + 1]
            fig.add_trace(go.Scatter(
                x=[pos[u][0], pos[v][0]],
                y=[pos[u][1], pos[v][1]],
                line=dict(width=4, color='red'),
                mode='lines',
                hoverinfo='none',
                showlegend=False
            ))

    # Nodos
    fig.add_trace(go.Scatter(
        x=[pos[n][0] for n in G.nodes()],
        y=[pos[n][1] for n in G.nodes()],
        mode='markers+text',
        text=list(G.nodes()),
        textposition="top center",
        marker=dict(
            color=[colores[tipos[n]] for n in G.nodes()],
            size=30,
            line=dict(width=2, color='black')
        )
    ))

    fig.update_layout(
        showlegend=False,
        hovermode='closest',
        margin=dict(l=20, r=20, t=40, b=20),
        xaxis=dict(showgrid=False, zeroline=False),
        yaxis=dict(showgrid=False, zeroline=False)
    )

    return fig

# Crear app
app = dash.Dash(__name__)
app.title = "Red de Transporte Inteligente"

app.layout = html.Div([
    html.H1("🗺️ Visualización de la Red de Transporte", style={'textAlign': 'center'}),

    html.Div([
        html.Label("Estación Origen:"),
        dcc.Dropdown(
            id='dropdown-origen',
            options=[{"label": nombre, "value": nombre} for nombre in grafo.vertices],
            placeholder="Selecciona origen"
        ),
        html.Label("Estación Destino:"),
        dcc.Dropdown(
            id='dropdown-destino',
            options=[{"label": nombre, "value": nombre} for nombre in grafo.vertices],
            placeholder="Selecciona destino"
        )
    ], style={'width': '50%', 'margin': 'auto'}),

    html.Div(id='salida-dijkstra', style={'textAlign': 'center', 'marginTop': '20px', 'fontSize': '18px'}),

    dcc.Graph(
        id='grafo-red',
        figure=construir_figura_grafo()
    )
])

@app.callback(
    [Output('salida-dijkstra', 'children'),
     Output('grafo-red', 'figure')],
    [Input('dropdown-origen', 'value'),
     Input('dropdown-destino', 'value')]
)
def mostrar_ruta_y_figura(origen, destino):
    if origen and destino:
        camino, tiempo = grafo.dijkstra(origen, destino)
        if camino:
            texto = f"📍 Ruta más corta de {origen} a {destino}: {' → '.join(camino)} ⏱️ {tiempo} min"
            figura = construir_figura_grafo(camino_resaltado=camino)
            return texto, figura
        else:
            return f"⚠️ No hay ruta disponible entre {origen} y {destino}.", construir_figura_grafo()
    return "", construir_figura_grafo()

if __name__ == '__main__':
    app.run(debug=True)
