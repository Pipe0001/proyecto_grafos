from src.utils import cargar_red_desde_json

def main():
    # Cargar el grafo desde el archivo JSON (puedes cambiar entre 'red_ejemplo.json' y 'red_con_ciclo.json' para probar)
    ruta_archivo = 'data/red_ejemplo.json'
    grafo = cargar_red_desde_json(ruta_archivo)

    print(" Estaciones en la red:")
    for nombre in grafo.vertices:
        print(f" - {nombre}")

    print("\n Rutas registradas:")
    for origen, edges in grafo.adjacency.items():
        for edge in edges:
            print(f" {edge.origin.name} -> {edge.destination.name} : {edge.weight} min")

    print(f"\n Resumen del grafo: {grafo}")

    # 🔍 Prueba de Dijkstra: Ruta más corta de A a D
    print("\n Ruta más corta de A a D:")
    camino, tiempo_total = grafo.dijkstra("A", "D")
    if camino:
        print(f" Camino: {' -> '.join(camino)}")
        print(f" Tiempo total estimado: {tiempo_total} minutos")
    else:
        print(" No hay ruta disponible entre A y D.")
        
    # 🔁 Prueba de detección de ciclos
    print("\n ¿La red contiene ciclos?")
    if grafo.tiene_ciclos():
        print(" Sí, se detectó al menos un ciclo en la red.")
    else:
        print(" No, la red no contiene ciclos.")

    # 🔗 Prueba de conectividad fuerte
    print("\n ¿La red es fuertemente conexa?")
    if grafo.es_fuertemente_conexo():
        print(" Sí, desde cualquier estación se puede llegar a cualquier otra.")
    else:
        print(" No, hay estaciones que no son accesibles desde todas las demás.")


    # ⚠️ Simulación de congestión y actualización de pesos
    print("\n Simulando congestión en las rutas salientes desde A (+10 min)...")

    # Mostrar ruta antes de congestión
    camino_original, tiempo_original = grafo.dijkstra("A", "D")
    print(f" Antes: Camino = {' -> '.join(camino_original)}, Tiempo = {tiempo_original} min")

    # Aplicar congestión
    grafo.simular_congestion(["A"], incremento=10)

    # Mostrar ruta después de congestión
    camino_nuevo, tiempo_nuevo = grafo.dijkstra("A", "D")
    print(f" Después: Camino = {' -> '.join(camino_nuevo)}, Tiempo = {tiempo_nuevo} min")


        # 💡 Sugerencias de nuevas conexiones dentro de un presupuesto
    presupuesto = 20  # en minutos
    print(f"\n💡 Sugerencias de nuevas conexiones (presupuesto máximo: {presupuesto} min):")

    sugerencias = grafo.sugerir_conexiones(presupuesto)

    if not sugerencias:
        print(" No se encontraron conexiones sugeridas dentro del presupuesto.")
    else:
        for origen, destino, tiempo_actual, sugerido, ahorro in sugerencias:
            print(f" - {origen} -> {destino} | Actual: {tiempo_actual} min, Sugerido: {sugerido} min, Ahorro: {ahorro} min")




    # === ¿Deseas editar la red?
    opcion = input("\n ¿Deseas editar la red manualmente? (s/n): ")
    if opcion.lower() == 's':
        while True:
            print("\n=== MENÚ DE EDICIÓN ===")
            print("1. Agregar estación")
            print("2. Agregar ruta")
            print("3. Eliminar estación")
            print("4. Eliminar ruta")
            print("5. Mostrar red actual")
            print("6. Salir del modo edición")
            eleccion = input("Elige una opción: ")

            if eleccion == "1":
                nombre = input("Nombre de la estación: ")
                tipo = input("Tipo de estación (opcional): ")
                grafo.add_vertex(nombre, tipo or "desconocido")
                print(" Estación agregada.")

            elif eleccion == "2":
                origen = input("Origen: ")
                destino = input("Destino: ")
                peso = float(input("Tiempo estimado (min): "))
                grafo.add_edge(origen, destino, peso)
                print(" Ruta agregada.")

            elif eleccion == "3":
                nombre = input("Nombre de la estación a eliminar: ")
                if grafo.remove_vertex(nombre):
                    print(" Estación eliminada.")
                else:
                    print(" Estación no encontrada.")

            elif eleccion == "4":
                origen = input("Origen de la ruta: ")
                destino = input("Destino de la ruta: ")
                if grafo.remove_edge(origen, destino):
                    print(" Ruta eliminada.")
                else:
                    print(" Ruta no encontrada.")

            elif eleccion == "5":
                print("\n Estaciones:")
                for nombre in grafo.vertices:
                    print(f" - {nombre}")
                print("\n Rutas:")
                for origen, edges in grafo.adjacency.items():
                    for edge in edges:
                        print(f" {edge.origin.name} -> {edge.destination.name} : {edge.weight} min")

            elif eleccion == "6":
                print(" Saliendo del modo edición.")
                break

            else:
                print(" Opción inválida.")



if __name__ == "__main__":
    main()


