class Vertex:
    def __init__(self, name: str, tipo: str = "desconocido"):
        self.name = name
        self.tipo = tipo

    def __repr__(self):
        return f"Vertex('{self.name}', tipo='{self.tipo}')"
