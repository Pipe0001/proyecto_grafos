from src.vertex import Vertex
from src.edge import Edge
import heapq

class Graph:
    """
    Clase que representa la red de transporte como un grafo dirigido y ponderado.
    """

    def __init__(self):
        self.vertices = {}  # Diccionario: nombre -> Vertex
        self.adjacency = {}  # Diccionario: nombre -> lista de Edge

    def add_vertex(self, name: str, tipo: str = "desconocido"):
        if name not in self.vertices:
            vertex = Vertex(name, tipo)  # <-- PASA tipo AQUÍ
            self.vertices[name] = vertex
            self.adjacency[name] = []


    def remove_vertex(self, name: str):
        if name in self.vertices:
            # Eliminar rutas entrantes
            for edges in self.adjacency.values():
                edges[:] = [e for e in edges if e.destination.name != name]
            # Eliminar vértice y sus rutas salientes
            del self.vertices[name]
            del self.adjacency[name]
            return True
        return False

    def add_edge(self, origin_name: str, destination_name: str, weight: float):
        if origin_name in self.vertices and destination_name in self.vertices:
            origin = self.vertices[origin_name]
            destination = self.vertices[destination_name]
            edge = Edge(origin, destination, weight)
            self.adjacency[origin_name].append(edge)

    def remove_edge(self, origin_name: str, destination_name: str):
        if origin_name in self.adjacency:
            self.adjacency[origin_name] = [
                e for e in self.adjacency[origin_name]
                if e.destination.name != destination_name
            ]
            return True
        return False

    def dijkstra(self, origen: str, destino: str):
        """
        Algoritmo de Dijkstra para encontrar la ruta más corta entre dos estaciones.
        :param origen: Estación inicial.
        :param destino: Estación destino.
        :return: (camino como lista de estaciones, tiempo total)
        """
        if origen not in self.vertices or destino not in self.vertices:
            return None, float('inf')

        distancias = {nombre: float('inf') for nombre in self.vertices}
        anteriores = {nombre: None for nombre in self.vertices}
        distancias[origen] = 0

        cola = [(0, origen)]

        while cola:
            distancia_actual, estacion_actual = heapq.heappop(cola)

            if estacion_actual == destino:
                break

            for arista in self.adjacency.get(estacion_actual, []):
                vecino = arista.destination.name
                nueva_distancia = distancia_actual + arista.weight

                if nueva_distancia < distancias[vecino]:
                    distancias[vecino] = nueva_distancia
                    anteriores[vecino] = estacion_actual
                    heapq.heappush(cola, (nueva_distancia, vecino))

        # Reconstruir camino
        camino = []
        actual = destino
        while actual:
            camino.insert(0, actual)
            actual = anteriores[actual]

        if distancias[destino] == float('inf'):
            return None, float('inf')

        return camino, distancias[destino]

    def __repr__(self):
        return f"Graph({len(self.vertices)} estaciones, {sum(len(v) for v in self.adjacency.values())} rutas)"


    def tiene_ciclos(self) -> bool:
        """
        Detecta si hay ciclos en el grafo usando DFS.
        :return: True si hay ciclos, False si no.
        """

        visitado = set()
        en_recorrido = set()

        def dfs(estacion: str) -> bool:
            visitado.add(estacion)
            en_recorrido.add(estacion)

            for arista in self.adjacency.get(estacion, []):
                vecino = arista.destination.name
                if vecino not in visitado:
                    if dfs(vecino):
                        return True
                elif vecino in en_recorrido:
                    return True  # Se encontró un ciclo

            en_recorrido.remove(estacion)
            return False

        for estacion in self.vertices:
            if estacion not in visitado:
                if dfs(estacion):
                    return True

        return False
    
    def es_fuertemente_conexo(self) -> bool:
        """
        Verifica si el grafo es fuertemente conexo usando DFS en el grafo original y su reverso.
        :return: True si lo es, False si no.
        """
        def dfs(estacion, visitado, adyacencia):
            visitado.add(estacion)
            for arista in adyacencia.get(estacion, []):
                vecino = arista.destination.name
                if vecino not in visitado:
                    dfs(vecino, visitado, adyacencia)

        # Paso 1: DFS en el grafo original
        estaciones = list(self.vertices.keys())
        visitado = set()
        dfs(estaciones[0], visitado, self.adjacency)

        if len(visitado) < len(self.vertices):
            return False

    # Paso 2: Crear grafo reverso
        reverso = {nombre: [] for nombre in self.vertices}
        for edges in self.adjacency.values():
            for edge in edges:
                origen = edge.origin.name
                destino = edge.destination.name
                reverso[destino].append(Edge(self.vertices[destino], self.vertices[origen], edge.weight))

    # Paso 3: DFS en grafo reverso
        visitado = set()
        dfs(estaciones[0], visitado, reverso)

        return len(visitado) == len(self.vertices)
    


    def actualizar_peso(self, origen: str, destino: str, nuevo_peso: float) -> bool:
        """
        Actualiza el peso (tiempo) de una ruta entre dos estaciones.
        :param origen: Estación de origen.
        :param destino: Estación de destino.
        :param nuevo_peso: Nuevo tiempo de la ruta.
        :return: True si se actualizó correctamente, False si la ruta no existe.
        """
        if origen in self.adjacency:
            for edge in self.adjacency[origen]:
                if edge.destination.name == destino:
                    edge.weight = nuevo_peso
                    return True
        return False
    
    def simular_congestion(self, estaciones_afectadas: list, incremento: float):
        """
        Aumenta el peso de todas las rutas salientes desde ciertas estaciones.
        :param estaciones_afectadas: Lista de nombres de estaciones afectadas.
        :param incremento: Cantidad a aumentar por congestión.
        """
        for origen in estaciones_afectadas:
            for edge in self.adjacency.get(origen, []):
                edge.weight += incremento



    def sugerir_conexiones(self, presupuesto: float) -> list:
        """
        Sugiere nuevas conexiones entre estaciones que reduzcan el tiempo total entre ellas,
        siempre que el nuevo tiempo propuesto esté dentro del presupuesto.

        :param presupuesto: Tiempo máximo permitido para nuevas rutas sugeridas.
        :return: Lista de tuplas (origen, destino, tiempo_actual, sugerido, ahorro)
        """
        sugerencias = []

        for origen in self.vertices:
            for destino in self.vertices:
                if origen == destino:
                    continue

            # Verificar si ya están conectados directamente
                ya_conectados = any(edge.destination.name == destino for edge in self.adjacency.get(origen, []))
                if ya_conectados:
                    continue

            # Calcular tiempo actual con Dijkstra
                _, tiempo_actual = self.dijkstra(origen, destino)

                if tiempo_actual == float('inf'):
                    continue  # No hay ruta posible

            # Propuesta: crear una ruta directa con menor tiempo
                tiempo_sugerido = tiempo_actual * 0.5  # Proponemos una ruta un 40% más rápida
                if tiempo_sugerido <= presupuesto:
                    ahorro = tiempo_actual - tiempo_sugerido
                    sugerencias.append((origen, destino, tiempo_actual, round(tiempo_sugerido, 2), round(ahorro, 2)))

            # Ordenar por mayor ahorro
        sugerencias.sort(key=lambda x: x[4], reverse=True)
        return sugerencias




