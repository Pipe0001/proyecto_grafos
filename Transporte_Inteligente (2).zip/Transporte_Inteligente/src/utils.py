import json
from src.graph import Graph

def cargar_red_desde_json(ruta_archivo: str) -> Graph:
    

    with open(ruta_archivo, 'r', encoding='utf-8') as f:
        datos = json.load(f)

    grafo = Graph()

    for estacion in datos["estaciones"]:
        if isinstance(estacion, dict):
            grafo.add_vertex(estacion["nombre"], estacion.get("tipo", "desconocido"))
        else:
            grafo.add_vertex(estacion)

    for ruta in datos["rutas"]:
        grafo.add_edge(ruta["origen"], ruta["destino"], ruta["tiempo"])

    return grafo
