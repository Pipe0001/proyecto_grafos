from src.vertex import Vertex

class Edge:
    """
    Clase que representa una ruta entre dos estaciones (vértices) con un peso (tiempo estimado).
    """

    def __init__(self, origin: Vertex, destination: Vertex, weight: float):
        """
        Inicializa una arista (ruta) entre dos estaciones.

        :param origin: Estación de origen.
        :param destination: Estación de destino.
        :param weight: Tiempo promedio de viaje entre las estaciones (en minutos).
        """
        self.origin = origin
        self.destination = destination
        self.weight = weight

    def __repr__(self) -> str:
        return f"Edge({self.origin.name} -> {self.destination.name}, {self.weight} min)"
